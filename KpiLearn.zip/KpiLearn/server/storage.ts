import { type Kpi, type InsertKpi, type UserProgress, type InsertUserProgress, type StudySession, type InsertStudySession, type DifficultyLevel } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // KPI methods
  getKpisByDifficulty(difficulty: DifficultyLevel): Promise<Kpi[]>;
  getKpiById(id: string): Promise<Kpi | undefined>;
  searchKpis(query: string): Promise<Kpi[]>;
  createKpi(kpi: InsertKpi): Promise<Kpi>;
  
  // User progress methods
  getUserProgress(userId: string): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, progress: Partial<UserProgress>): Promise<UserProgress>;
  
  // Study session methods
  createStudySession(session: InsertStudySession): Promise<StudySession>;
  getUserStudySessions(userId: string): Promise<StudySession[]>;
}

export class MemStorage implements IStorage {
  private kpis: Map<string, Kpi>;
  private userProgress: Map<string, UserProgress>;
  private studySessions: Map<string, StudySession>;

  constructor() {
    this.kpis = new Map();
    this.userProgress = new Map();
    this.studySessions = new Map();
    
    // Initialize with KPI data
    this.initializeKpis();
  }

  private initializeKpis() {
    const defaultKpis: Kpi[] = [
      // Beginner KPIs
      {
        id: "1",
        question: "What does DAU stand for?",
        answer: "Daily Active Users",
        explanation: "The number of unique users who engage with your product within a 24-hour period. It's a key metric for measuring user engagement and product stickiness.",
        difficulty: "beginner",
        category: "Engagement",
        tags: ["users", "engagement", "daily"]
      },
      {
        id: "2",
        question: "What does MAU represent?",
        answer: "Monthly Active Users",
        explanation: "The number of unique users who engage with your product within a 30-day period. Used to measure long-term user engagement and growth trends.",
        difficulty: "beginner",
        category: "Engagement",
        tags: ["users", "engagement", "monthly"]
      },
      {
        id: "3",
        question: "What is NPS?",
        answer: "Net Promoter Score",
        explanation: "A customer satisfaction metric that measures how likely customers are to recommend your product, scored from -100 to +100.",
        difficulty: "beginner",
        category: "Customer Satisfaction",
        tags: ["satisfaction", "loyalty", "survey"]
      },
      {
        id: "4",
        question: "What does CTR stand for?",
        answer: "Click-Through Rate",
        explanation: "The percentage of users who click on a specific link or call-to-action compared to the total number who view it.",
        difficulty: "beginner",
        category: "Marketing",
        tags: ["clicks", "conversion", "marketing"]
      },
      {
        id: "5",
        question: "What is conversion rate?",
        answer: "The percentage of users who complete a desired action",
        explanation: "Measures the effectiveness of your product in getting users to take specific actions, from sign-ups to purchases.",
        difficulty: "beginner",
        category: "Conversion",
        tags: ["conversion", "funnel", "optimization"]
      },

      // Intermediate KPIs
      {
        id: "6",
        question: "How do you calculate Customer Acquisition Cost (CAC)?",
        answer: "Total Sales & Marketing Costs ÷ Number of New Customers",
        explanation: "CAC helps determine how much it costs to acquire each new customer, essential for understanding unit economics and marketing efficiency.",
        difficulty: "intermediate",
        category: "Economics",
        tags: ["acquisition", "cost", "marketing"]
      },
      {
        id: "7",
        question: "What is Customer Lifetime Value (LTV)?",
        answer: "The total revenue expected from a customer over their entire relationship",
        explanation: "LTV helps determine how much you can spend on customer acquisition while maintaining profitability.",
        difficulty: "intermediate",
        category: "Economics",
        tags: ["lifetime", "revenue", "retention"]
      },
      {
        id: "8",
        question: "How do you measure cohort retention?",
        answer: "Track what percentage of users return after specific time periods",
        explanation: "Cohort analysis reveals how well you retain users over time, showing product stickiness and long-term value delivery.",
        difficulty: "intermediate",
        category: "Retention",
        tags: ["cohort", "retention", "analysis"]
      },
      {
        id: "9",
        question: "What is churn rate?",
        answer: "The percentage of customers who stop using your product over a period",
        explanation: "Churn rate is critical for subscription businesses and indicates customer satisfaction and product-market fit.",
        difficulty: "intermediate",
        category: "Retention",
        tags: ["churn", "retention", "subscription"]
      },
      {
        id: "10",
        question: "What does ARPU stand for?",
        answer: "Average Revenue Per User",
        explanation: "ARPU measures the average amount of revenue generated per user over a specific period, helping assess monetization effectiveness.",
        difficulty: "intermediate",
        category: "Revenue",
        tags: ["revenue", "monetization", "average"]
      },

      // Advanced KPIs
      {
        id: "11",
        question: "What is a North Star Metric?",
        answer: "A single key metric that captures the core value your product delivers",
        explanation: "The North Star Metric aligns the entire organization around what matters most for long-term success and customer value creation.",
        difficulty: "advanced",
        category: "Strategy",
        tags: ["strategy", "alignment", "value"]
      },
      {
        id: "12",
        question: "How do you calculate the LTV:CAC ratio?",
        answer: "Customer Lifetime Value ÷ Customer Acquisition Cost",
        explanation: "A healthy LTV:CAC ratio (typically 3:1 or higher) indicates sustainable unit economics and efficient customer acquisition.",
        difficulty: "advanced",
        category: "Economics",
        tags: ["ltv", "cac", "ratio", "economics"]
      },
      {
        id: "13",
        question: "What are leading vs lagging indicators?",
        answer: "Leading indicators predict future performance; lagging indicators measure past results",
        explanation: "Leading indicators help you make proactive decisions, while lagging indicators confirm whether your strategies worked.",
        difficulty: "advanced",
        category: "Strategy",
        tags: ["indicators", "prediction", "strategy"]
      },
      {
        id: "14",
        question: "What is product-market fit measurement?",
        answer: "When at least 40% of users would be 'very disappointed' without your product",
        explanation: "This threshold, established by Sean Ellis, indicates strong product-market fit and sustainable growth potential.",
        difficulty: "advanced",
        category: "Product",
        tags: ["pmf", "survey", "product"]
      },
      {
        id: "15",
        question: "What drives sustainable growth loops?",
        answer: "Viral coefficients, network effects, and content/data network effects",
        explanation: "Understanding growth loops helps build products that grow organically through user behavior rather than paid acquisition.",
        difficulty: "advanced",
        category: "Growth",
        tags: ["growth", "viral", "network", "loops"]
      },

      // Additional Beginner KPIs
      {
        id: "16",
        question: "What is bounce rate?",
        answer: "The percentage of visitors who leave after viewing only one page",
        explanation: "A high bounce rate may indicate poor user experience, irrelevant content, or slow loading times.",
        difficulty: "beginner",
        category: "Analytics",
        tags: ["bounce", "analytics", "engagement"]
      },
      {
        id: "17",
        question: "What does CPC stand for?",
        answer: "Cost Per Click",
        explanation: "The amount you pay each time someone clicks on your advertisement or sponsored content.",
        difficulty: "beginner",
        category: "Marketing",
        tags: ["advertising", "cost", "clicks"]
      },
      {
        id: "18",
        question: "What is a funnel conversion rate?",
        answer: "The percentage of users who complete all steps in a process",
        explanation: "Measures how effectively users move through each stage of your product funnel from awareness to conversion.",
        difficulty: "beginner",
        category: "Conversion",
        tags: ["funnel", "conversion", "process"]
      },
      {
        id: "19",
        question: "What is session duration?",
        answer: "The average time users spend on your product in one visit",
        explanation: "Longer sessions typically indicate higher engagement and better user experience.",
        difficulty: "beginner",
        category: "Engagement",
        tags: ["session", "time", "engagement"]
      },
      {
        id: "20",
        question: "What does MRR stand for?",
        answer: "Monthly Recurring Revenue",
        explanation: "The predictable revenue generated each month from subscriptions and recurring customers.",
        difficulty: "beginner",
        category: "Revenue",
        tags: ["revenue", "recurring", "subscription"]
      },

      // Additional Intermediate KPIs
      {
        id: "21",
        question: "What is feature adoption rate?",
        answer: "The percentage of users who actively use a specific feature",
        explanation: "Helps prioritize product development and identify which features drive value for users.",
        difficulty: "intermediate",
        category: "Product",
        tags: ["features", "adoption", "usage"]
      },
      {
        id: "22",
        question: "How do you calculate payback period?",
        answer: "Customer Acquisition Cost ÷ Monthly Revenue Per Customer",
        explanation: "The time it takes to recover the cost of acquiring a new customer through their revenue.",
        difficulty: "intermediate",
        category: "Economics",
        tags: ["payback", "acquisition", "recovery"]
      },
      {
        id: "23",
        question: "What is Time to Value (TTV)?",
        answer: "How quickly users experience meaningful value from your product",
        explanation: "Shorter TTV leads to better retention and reduced churn in the critical early stages.",
        difficulty: "intermediate",
        category: "Onboarding",
        tags: ["onboarding", "value", "time"]
      },
      {
        id: "24",
        question: "What is Product Qualified Lead (PQL)?",
        answer: "A user who has experienced value through product usage",
        explanation: "PQLs typically convert better than marketing qualified leads because they've already found product value.",
        difficulty: "intermediate",
        category: "Sales",
        tags: ["leads", "qualification", "conversion"]
      },
      {
        id: "25",
        question: "What is expansion revenue?",
        answer: "Additional revenue from existing customers through upgrades or add-ons",
        explanation: "Often more cost-effective than acquiring new customers and indicates strong product-market fit.",
        difficulty: "intermediate",
        category: "Revenue",
        tags: ["expansion", "upsell", "growth"]
      },
      {
        id: "26",
        question: "What is activation rate?",
        answer: "The percentage of new users who complete key onboarding actions",
        explanation: "Measures how well your product guides users to experience core value during their first experience.",
        difficulty: "intermediate",
        category: "Onboarding",
        tags: ["activation", "onboarding", "new users"]
      },
      {
        id: "27",
        question: "What is Net Revenue Retention (NRR)?",
        answer: "Revenue retained from existing customers including expansions and churn",
        explanation: "NRR above 100% means your existing customers are growing their spending faster than others are churning.",
        difficulty: "intermediate",
        category: "Retention",
        tags: ["retention", "revenue", "expansion"]
      },

      // Additional Advanced KPIs
      {
        id: "28",
        question: "What is the T2D3 growth framework?",
        answer: "Triple, Triple, Double, Double, Double - SaaS growth pattern",
        explanation: "A benchmark for SaaS companies to scale from $2M to $100M ARR over 5 years.",
        difficulty: "advanced",
        category: "Strategy",
        tags: ["growth", "framework", "scaling"]
      },
      {
        id: "29",
        question: "What is the Magic Number in SaaS?",
        answer: "Sales efficiency metric = (Net New ARR x 4) ÷ Sales & Marketing Spend",
        explanation: "Values above 1.0 indicate efficient growth. Below 0.5 suggests need to optimize go-to-market strategy.",
        difficulty: "advanced",
        category: "Economics",
        tags: ["efficiency", "sales", "magic number"]
      },
      {
        id: "30",
        question: "What is a cohort retention curve?",
        answer: "Chart showing how user retention changes over time for specific user groups",
        explanation: "Helps identify when users typically churn and what behaviors lead to long-term retention.",
        difficulty: "advanced",
        category: "Analytics",
        tags: ["cohort", "retention", "analytics"]
      },
      {
        id: "31",
        question: "What is the Rule of 40?",
        answer: "Growth rate + Profit margin should exceed 40% for healthy SaaS",
        explanation: "Balances growth and profitability. Companies can prioritize either but the sum should be ≥40%.",
        difficulty: "advanced",
        category: "Strategy",
        tags: ["profitability", "growth", "balance"]
      },
      {
        id: "32",
        question: "What is customer health scoring?",
        answer: "Predictive model combining usage, engagement, and support metrics",
        explanation: "Helps identify at-risk customers before they churn and opportunities for expansion.",
        difficulty: "advanced",
        category: "Analytics",
        tags: ["health", "prediction", "risk"]
      },
      {
        id: "33",
        question: "What is the viral coefficient (k-factor)?",
        answer: "Average number of new users each existing user brings",
        explanation: "K > 1.0 means exponential growth. Most successful viral products have k-factors of 0.15-0.25.",
        difficulty: "advanced",
        category: "Growth",
        tags: ["viral", "referral", "coefficient"]
      },

      // UX/Design Specific KPIs
      {
        id: "34",
        question: "What is System Usability Scale (SUS)?",
        answer: "10-question survey measuring perceived usability (0-100 score)",
        explanation: "Scores above 68 are above average, above 80 are excellent. Quick way to benchmark usability.",
        difficulty: "intermediate",
        category: "UX",
        tags: ["usability", "survey", "measurement"]
      },
      {
        id: "35",
        question: "What is task completion rate?",
        answer: "Percentage of users who successfully complete a specific task",
        explanation: "Core UX metric that directly measures how well your design enables users to achieve their goals.",
        difficulty: "beginner",
        category: "UX",
        tags: ["task", "completion", "success"]
      },
      {
        id: "36",
        question: "What is error rate in UX?",
        answer: "Frequency of user mistakes during task completion",
        explanation: "High error rates indicate confusing interface design or unclear user flows.",
        difficulty: "intermediate",
        category: "UX",
        tags: ["errors", "mistakes", "usability"]
      },
      {
        id: "37",
        question: "What is time on task?",
        answer: "How long it takes users to complete a specific action",
        explanation: "Longer times may indicate poor UX design, but some complexity is unavoidable for complex tasks.",
        difficulty: "beginner",
        category: "UX",
        tags: ["time", "efficiency", "task"]
      },
      {
        id: "38",
        question: "What is the aesthetic-usability effect?",
        answer: "Users perceive attractive designs as more usable",
        explanation: "Beautiful interfaces create positive first impressions and increase user tolerance for minor usability issues.",
        difficulty: "advanced",
        category: "UX",
        tags: ["aesthetics", "perception", "psychology"]
      },

      // E-commerce & Product KPIs
      {
        id: "39",
        question: "What is cart abandonment rate?",
        answer: "Percentage of shopping carts that are created but not completed",
        explanation: "Average rate is 70%. Common causes: unexpected costs, required registration, or complex checkout.",
        difficulty: "intermediate",
        category: "E-commerce",
        tags: ["cart", "abandonment", "checkout"]
      },
      {
        id: "40",
        question: "What is Average Order Value (AOV)?",
        answer: "Total revenue divided by number of orders",
        explanation: "Key metric for e-commerce businesses to understand customer spending patterns and optimize pricing.",
        difficulty: "beginner",
        category: "E-commerce",
        tags: ["order", "value", "revenue"]
      },
      {
        id: "41",
        question: "What is Return on Ad Spend (ROAS)?",
        answer: "Revenue generated for every dollar spent on advertising",
        explanation: "ROAS of 4:1 means $4 revenue for every $1 ad spend. Varies by industry and channel.",
        difficulty: "intermediate",
        category: "Marketing",
        tags: ["advertising", "return", "efficiency"]
      },
      {
        id: "42",
        question: "What is product velocity?",
        answer: "Rate at which product features are developed and shipped",
        explanation: "Balances speed with quality. Track features shipped, bugs introduced, and user satisfaction.",
        difficulty: "advanced",
        category: "Product",
        tags: ["velocity", "development", "shipping"]
      },
      {
        id: "43",
        question: "What is technical debt ratio?",
        answer: "Cost to fix code issues vs. cost to develop new features",
        explanation: "High ratios slow down product development and increase bug rates over time.",
        difficulty: "advanced",
        category: "Technical",
        tags: ["debt", "technical", "maintenance"]
      },

      // Advanced Analytics & Data KPIs
      {
        id: "44",
        question: "What is statistical significance?",
        answer: "Confidence that test results are not due to chance",
        explanation: "Usually set at 95% confidence (p < 0.05). Critical for validating A/B test results.",
        difficulty: "advanced",
        category: "Analytics",
        tags: ["statistics", "testing", "confidence"]
      },
      {
        id: "45",
        question: "What is cohort analysis?",
        answer: "Grouping users by shared characteristics to track behavior over time",
        explanation: "Helps identify patterns in user behavior, retention, and lifetime value across different user segments.",
        difficulty: "intermediate",
        category: "Analytics",
        tags: ["cohort", "segmentation", "behavior"]
      }
    ];

    defaultKpis.forEach(kpi => {
      this.kpis.set(kpi.id, kpi);
    });
  }

  async getKpisByDifficulty(difficulty: DifficultyLevel): Promise<Kpi[]> {
    return Array.from(this.kpis.values()).filter(kpi => kpi.difficulty === difficulty);
  }

  async getKpiById(id: string): Promise<Kpi | undefined> {
    return this.kpis.get(id);
  }

  async searchKpis(query: string): Promise<Kpi[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.kpis.values()).filter(kpi => 
      kpi.question.toLowerCase().includes(searchTerm) ||
      kpi.answer.toLowerCase().includes(searchTerm) ||
      kpi.explanation.toLowerCase().includes(searchTerm) ||
      kpi.tags?.some(tag => tag.toLowerCase().includes(searchTerm))
    );
  }

  async createKpi(insertKpi: InsertKpi): Promise<Kpi> {
    const id = randomUUID();
    const kpi: Kpi = { 
      ...insertKpi, 
      id,
      category: insertKpi.category || null,
      tags: insertKpi.tags || null
    };
    this.kpis.set(id, kpi);
    return kpi;
  }

  async getUserProgress(userId: string): Promise<UserProgress | undefined> {
    return this.userProgress.get(userId);
  }

  async updateUserProgress(userId: string, progress: Partial<UserProgress>): Promise<UserProgress> {
    const existing = this.userProgress.get(userId);
    const updated: UserProgress = {
      id: existing?.id || randomUUID(),
      userId,
      currentStreak: 0,
      lastPracticeDate: null,
      todaysProgress: 0,
      totalCardsStudied: 0,
      bookmarkedKpis: [],
      ...existing,
      ...progress
    };
    this.userProgress.set(userId, updated);
    return updated;
  }

  async createStudySession(insertSession: InsertStudySession): Promise<StudySession> {
    const id = randomUUID();
    const session: StudySession = { 
      ...insertSession, 
      id,
      userId: insertSession.userId || null,
      isDaily: insertSession.isDaily || null,
      completedAt: new Date()
    };
    this.studySessions.set(id, session);
    return session;
  }

  async getUserStudySessions(userId: string): Promise<StudySession[]> {
    return Array.from(this.studySessions.values()).filter(session => session.userId === userId);
  }
}

export const storage = new MemStorage();
