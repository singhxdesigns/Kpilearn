import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get KPIs by difficulty
  app.get("/api/kpis/:difficulty", async (req, res) => {
    try {
      const difficulty = req.params.difficulty as "beginner" | "intermediate" | "advanced";
      const kpis = await storage.getKpisByDifficulty(difficulty);
      res.json(kpis);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch KPIs" });
    }
  });

  // Search KPIs
  app.get("/api/kpis/search/:query", async (req, res) => {
    try {
      const query = req.params.query;
      const kpis = await storage.searchKpis(query);
      res.json(kpis);
    } catch (error) {
      res.status(500).json({ message: "Failed to search KPIs" });
    }
  });

  // Get user progress
  app.get("/api/progress/:userId", async (req, res) => {
    try {
      const userId = req.params.userId;
      const progress = await storage.getUserProgress(userId);
      if (!progress) {
        // Create default progress for new user
        const defaultProgress = await storage.updateUserProgress(userId, {
          currentStreak: 0,
          todaysProgress: 0,
          totalCardsStudied: 0,
          bookmarkedKpis: []
        });
        res.json(defaultProgress);
      } else {
        res.json(progress);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user progress" });
    }
  });

  // Update user progress
  app.patch("/api/progress/:userId", async (req, res) => {
    try {
      const userId = req.params.userId;
      const updateData = req.body;
      const progress = await storage.updateUserProgress(userId, updateData);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user progress" });
    }
  });

  // Create study session
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = req.body;
      const session = await storage.createStudySession(sessionData);
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to create study session" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
