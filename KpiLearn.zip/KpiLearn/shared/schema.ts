import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const kpis = pgTable("kpis", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  explanation: text("explanation").notNull(),
  difficulty: varchar("difficulty", { length: 20 }).notNull(),
  category: varchar("category", { length: 50 }),
  tags: text("tags").array(),
});

export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  currentStreak: integer("current_streak").default(0),
  lastPracticeDate: timestamp("last_practice_date"),
  todaysProgress: integer("todays_progress").default(0),
  totalCardsStudied: integer("total_cards_studied").default(0),
  bookmarkedKpis: text("bookmarked_kpis").array().default(sql`'{}'::text[]`),
});

export const studySessions = pgTable("study_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  difficulty: varchar("difficulty", { length: 20 }).notNull(),
  cardsStudied: integer("cards_studied").notNull(),
  completedAt: timestamp("completed_at").defaultNow(),
  isDaily: boolean("is_daily").default(false),
});

export const insertKpiSchema = createInsertSchema(kpis).omit({
  id: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
});

export const insertStudySessionSchema = createInsertSchema(studySessions).omit({
  id: true,
});

export type Kpi = typeof kpis.$inferSelect;
export type InsertKpi = z.infer<typeof insertKpiSchema>;
export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type StudySession = typeof studySessions.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;

export type DifficultyLevel = "beginner" | "intermediate" | "advanced";
