import type { Kpi } from "@shared/schema";

export const kpiData: Record<string, Kpi[]> = {
  beginner: [
    {
      id: "1",
      question: "What does DAU stand for?",
      answer: "Daily Active Users",
      explanation: "The number of unique users who engage with your product within a 24-hour period. It's a key metric for measuring user engagement and product stickiness.",
      difficulty: "beginner",
      category: "Engagement",
      tags: ["users", "engagement", "daily"]
    },
    {
      id: "2", 
      question: "What does MAU represent?",
      answer: "Monthly Active Users",
      explanation: "The number of unique users who engage with your product within a 30-day period. Used to measure long-term user engagement and growth trends.",
      difficulty: "beginner",
      category: "Engagement",
      tags: ["users", "engagement", "monthly"]
    },
    {
      id: "3",
      question: "What is NPS?",
      answer: "Net Promoter Score", 
      explanation: "A customer satisfaction metric that measures how likely customers are to recommend your product, scored from -100 to +100.",
      difficulty: "beginner",
      category: "Customer Satisfaction",
      tags: ["satisfaction", "loyalty", "survey"]
    },
    {
      id: "4",
      question: "What does CTR stand for?",
      answer: "Click-Through Rate",
      explanation: "The percentage of users who click on a specific link or call-to-action compared to the total number who view it.",
      difficulty: "beginner", 
      category: "Marketing",
      tags: ["clicks", "conversion", "marketing"]
    },
    {
      id: "5",
      question: "What is conversion rate?",
      answer: "The percentage of users who complete a desired action",
      explanation: "Measures the effectiveness of your product in getting users to take specific actions, from sign-ups to purchases.",
      difficulty: "beginner",
      category: "Conversion", 
      tags: ["conversion", "funnel", "optimization"]
    }
  ],
  
  intermediate: [
    {
      id: "6",
      question: "How do you calculate Customer Acquisition Cost (CAC)?",
      answer: "Total Sales & Marketing Costs ÷ Number of New Customers",
      explanation: "CAC helps determine how much it costs to acquire each new customer, essential for understanding unit economics and marketing efficiency.",
      difficulty: "intermediate",
      category: "Economics",
      tags: ["acquisition", "cost", "marketing"]
    },
    {
      id: "7",
      question: "What is Customer Lifetime Value (LTV)?", 
      answer: "The total revenue expected from a customer over their entire relationship",
      explanation: "LTV helps determine how much you can spend on customer acquisition while maintaining profitability.",
      difficulty: "intermediate",
      category: "Economics",
      tags: ["lifetime", "revenue", "retention"]
    },
    {
      id: "8",
      question: "How do you measure cohort retention?",
      answer: "Track what percentage of users return after specific time periods",
      explanation: "Cohort analysis reveals how well you retain users over time, showing product stickiness and long-term value delivery.",
      difficulty: "intermediate",
      category: "Retention",
      tags: ["cohort", "retention", "analysis"]
    },
    {
      id: "9",
      question: "What is churn rate?",
      answer: "The percentage of customers who stop using your product over a period",
      explanation: "Churn rate is critical for subscription businesses and indicates customer satisfaction and product-market fit.",
      difficulty: "intermediate",
      category: "Retention", 
      tags: ["churn", "retention", "subscription"]
    },
    {
      id: "10",
      question: "What does ARPU stand for?",
      answer: "Average Revenue Per User",
      explanation: "ARPU measures the average amount of revenue generated per user over a specific period, helping assess monetization effectiveness.",
      difficulty: "intermediate",
      category: "Revenue",
      tags: ["revenue", "monetization", "average"]
    }
  ],
  
  advanced: [
    {
      id: "11",
      question: "What is a North Star Metric?",
      answer: "A single key metric that captures the core value your product delivers",
      explanation: "The North Star Metric aligns the entire organization around what matters most for long-term success and customer value creation.",
      difficulty: "advanced",
      category: "Strategy", 
      tags: ["strategy", "alignment", "value"]
    },
    {
      id: "12",
      question: "How do you calculate the LTV:CAC ratio?",
      answer: "Customer Lifetime Value ÷ Customer Acquisition Cost",
      explanation: "A healthy LTV:CAC ratio (typically 3:1 or higher) indicates sustainable unit economics and efficient customer acquisition.",
      difficulty: "advanced",
      category: "Economics",
      tags: ["ltv", "cac", "ratio", "economics"]
    },
    {
      id: "13",
      question: "What are leading vs lagging indicators?",
      answer: "Leading indicators predict future performance; lagging indicators measure past results",
      explanation: "Leading indicators help you make proactive decisions, while lagging indicators confirm whether your strategies worked.",
      difficulty: "advanced",
      category: "Strategy",
      tags: ["indicators", "prediction", "strategy"]
    },
    {
      id: "14", 
      question: "What is product-market fit measurement?",
      answer: "When at least 40% of users would be 'very disappointed' without your product",
      explanation: "This threshold, established by Sean Ellis, indicates strong product-market fit and sustainable growth potential.",
      difficulty: "advanced",
      category: "Product",
      tags: ["pmf", "survey", "product"]
    },
    {
      id: "15",
      question: "What drives sustainable growth loops?",
      answer: "Viral coefficients, network effects, and content/data network effects",
      explanation: "Understanding growth loops helps build products that grow organically through user behavior rather than paid acquisition.",
      difficulty: "advanced",
      category: "Growth",
      tags: ["growth", "viral", "network", "loops"]
    }
  ]
};
