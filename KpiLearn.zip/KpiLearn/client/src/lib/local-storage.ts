import type { UserProgress } from "@shared/schema";

const USER_ID_KEY = "kpi_flashcards_user_id";
const BOOKMARKS_KEY = "kpi_flashcards_bookmarks";
const USER_PROGRESS_KEY = "kpi_flashcards_progress";

export function getUserId(): string {
  let userId = localStorage.getItem(USER_ID_KEY);
  if (!userId) {
    userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem(USER_ID_KEY, userId);
  }
  return userId;
}

export function getBookmarkedKpis(): string[] {
  const bookmarks = localStorage.getItem(BOOKMARKS_KEY);
  return bookmarks ? JSON.parse(bookmarks) : [];
}

export function toggleBookmark(kpiId: string): void {
  const bookmarks = getBookmarkedKpis();
  const index = bookmarks.indexOf(kpiId);
  
  if (index > -1) {
    bookmarks.splice(index, 1);
  } else {
    bookmarks.push(kpiId);
  }
  
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(bookmarks));
}

export function getUserProgress(): Partial<UserProgress> {
  const progress = localStorage.getItem(USER_PROGRESS_KEY);
  return progress ? JSON.parse(progress) : {};
}

export function updateUserProgress(updates: Partial<UserProgress>): void {
  const current = getUserProgress();
  const updated = { ...current, ...updates };
  localStorage.setItem(USER_PROGRESS_KEY, JSON.stringify(updated));
}

export function resetDailyProgress(): void {
  const current = getUserProgress();
  updateUserProgress({
    ...current,
    todaysProgress: 0
  });
}

export function incrementStreak(): void {
  const current = getUserProgress();
  updateUserProgress({
    ...current,
    currentStreak: (current.currentStreak || 0) + 1,
    lastPracticeDate: new Date()
  });
}
