import { cn } from "@/lib/utils";

interface ProgressBarProps {
  current: number;
  total: number;
  className?: string;
}

export function ProgressBar({ current, total, className }: ProgressBarProps) {
  const percentage = (current / total) * 100;
  
  return (
    <div className={cn("bg-slate-200 rounded-full h-3 overflow-hidden", className)}>
      <div 
        className="bg-primary h-full rounded-full transition-all duration-300" 
        style={{ width: `${percentage}%` }}
      />
    </div>
  );
}
