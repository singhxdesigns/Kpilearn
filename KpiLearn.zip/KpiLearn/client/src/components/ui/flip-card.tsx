import { cn } from "@/lib/utils";

interface FlipCardProps {
  question: string;
  answer: string;
  explanation: string;
  isFlipped: boolean;
  onFlip: () => void;
  className?: string;
}

export function FlipCard({ 
  question, 
  answer, 
  explanation, 
  isFlipped, 
  onFlip, 
  className 
}: FlipCardProps) {
  return (
    <div className={cn("flip-card w-full h-80 cursor-pointer", className)} onClick={onFlip}>
      <div className={cn("flip-card-inner", isFlipped && "flipped")}>
        {/* Front of Card (Question) */}
        <div className="flip-card-front bg-white shadow-xl border border-slate-100 flex items-center justify-center p-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="fas fa-question text-white text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-slate-800 mb-4">{question}</h3>
            <p className="text-slate-500 text-sm">Tap to reveal answer</p>
          </div>
        </div>
        
        {/* Back of Card (Answer) */}
        <div className="flip-card-back bg-success shadow-xl flex items-center justify-center p-8">
          <div className="text-center text-white">
            <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="fas fa-lightbulb text-white text-2xl"></i>
            </div>
            <h3 className="text-xl font-bold mb-4">{answer}</h3>
            <p className="text-sm opacity-90 leading-relaxed">{explanation}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
