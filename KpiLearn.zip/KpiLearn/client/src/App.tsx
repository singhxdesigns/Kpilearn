import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "./pages/not-found";
import Home from "./pages/home";
import DifficultySelect from "./pages/difficulty-select";
import Flashcard from "./pages/flashcard";
import Search from "./pages/search";
import Bookmarks from "./pages/bookmarks";
import Completion from "./pages/completion";
import Library from "./pages/library";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/difficulty" component={DifficultySelect} />
      <Route path="/flashcard/:difficulty" component={Flashcard} />
      <Route path="/search" component={Search} />
      <Route path="/bookmarks" component={Bookmarks} />
      <Route path="/library" component={Library} />
      <Route path="/completion" component={Completion} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
