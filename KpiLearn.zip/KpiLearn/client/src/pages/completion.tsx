import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getUserId } from "../lib/local-storage";
import type { UserProgress } from "@shared/schema";

export default function Completion() {
  const [userId] = useState(() => getUserId());

  const { data: progress } = useQuery<UserProgress>({
    queryKey: ["/api/progress", userId],
  });

  const streak = progress?.currentStreak || 1;
  const cardsStudied = 5; // For daily practice, it's always 5

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <div className="text-center">
          <div className="w-24 h-24 bg-success rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-check text-white text-3xl"></i>
          </div>
          
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Great Job!</h2>
          <p className="text-lg text-slate-600 mb-8">You've completed today's practice session</p>
          
          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-white rounded-xl shadow-lg p-4">
              <p className="text-2xl font-bold text-slate-800">{cardsStudied}</p>
              <p className="text-sm text-slate-600">Cards Studied</p>
            </div>
            <div className="bg-white rounded-xl shadow-lg p-4">
              <p className="text-2xl font-bold text-warning">{streak}</p>
              <p className="text-sm text-slate-600">Day Streak</p>
            </div>
          </div>
          
          <Link href="/">
            <button className="w-full bg-primary hover:bg-blue-600 text-white font-semibold py-4 px-6 rounded-xl shadow-lg transition-all duration-200">
              <i className="fas fa-home mr-2"></i>
              Back to Home
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}


