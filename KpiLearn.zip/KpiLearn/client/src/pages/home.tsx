import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { getUserId, getUserProgress, updateUserProgress } from "../lib/local-storage";
import type { UserProgress } from "@shared/schema";

export default function Home() {
  const [userId] = useState(getUserId());

  const { data: progress, isLoading } = useQuery<UserProgress>({
    queryKey: ["/api/progress", userId],
  });

  // Fetch all KPIs to show total count
  const { data: beginnerKpis } = useQuery<any[]>({
    queryKey: ["/api/kpis", "beginner"],
  });
  const { data: intermediateKpis } = useQuery<any[]>({
    queryKey: ["/api/kpis", "intermediate"],
  });
  const { data: advancedKpis } = useQuery<any[]>({
    queryKey: ["/api/kpis", "advanced"],
  });

  const allKpis = [
    ...(beginnerKpis || []),
    ...(intermediateKpis || []),
    ...(advancedKpis || [])
  ];

  // Check if it's a new day and reset daily progress
  useEffect(() => {
    if (progress) {
      const today = new Date().toDateString();
      const lastPracticeDate = progress.lastPracticeDate ? new Date(progress.lastPracticeDate).toDateString() : null;
      
      if (lastPracticeDate !== today && (progress.todaysProgress || 0) > 0) {
        // Reset daily progress for new day
        updateUserProgress({ todaysProgress: 0 });
      }
    }
  }, [progress]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const streak = progress?.currentStreak || 0;
  const todayProgress = progress?.todaysProgress || 0;

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <div className="text-center mb-12">
          <div className="mb-6">
            <i className="fas fa-chart-line text-6xl text-primary mb-4"></i>
          </div>
          <h1 className="text-3xl font-bold text-slate-800 mb-3">KPI Flashcards</h1>
          <p className="text-lg text-slate-600 leading-relaxed">
            Sharpen your product metrics knowledge, one card a day.
          </p>
        </div>
        
        {/* Daily Streak Display */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8 border border-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-warning rounded-full flex items-center justify-center">
                <i className="fas fa-fire text-white text-xl"></i>
              </div>
              <div>
                <p className="text-sm text-slate-600">Current Streak</p>
                <p className="text-2xl font-bold text-slate-800">{streak}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-600">Today's Progress</p>
              <p className="text-lg font-semibold text-success">{todayProgress}/5 cards</p>
            </div>
          </div>
        </div>

        {/* Main Action Buttons */}
        <div className="space-y-4 mb-8">
          <Link href="/flashcard/daily">
            <button className="w-full bg-primary hover:bg-blue-600 text-white font-semibold py-4 px-6 rounded-xl shadow-lg transition-all duration-200 transform hover:scale-105">
              <i className="fas fa-play mr-2"></i>
              Start Daily Practice
            </button>
          </Link>
          
          <Link href="/difficulty">
            <button className="w-full bg-white hover:bg-slate-50 text-slate-800 font-semibold py-4 px-6 rounded-xl shadow-lg border border-slate-200 transition-all duration-200">
              <i className="fas fa-layer-group mr-2"></i>
              Choose Difficulty
            </button>
          </Link>
        </div>

        {/* KPI Library Button */}
        <div className="mb-6">
          <Link href="/library">
            <button className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-4 px-6 rounded-xl shadow-lg transition-all duration-200 transform hover:scale-105">
              <i className="fas fa-book-open mr-2"></i>
              Browse All KPIs ({allKpis?.length || 45})
            </button>
          </Link>
        </div>

        {/* Secondary Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Link href="/search">
            <button className="bg-white hover:bg-slate-50 text-slate-700 font-medium py-3 px-4 rounded-lg shadow-md border border-slate-200 transition-all duration-200 w-full">
              <i className="fas fa-search mr-2"></i>
              Search KPIs
            </button>
          </Link>
          
          <Link href="/bookmarks">
            <button className="bg-white hover:bg-slate-50 text-slate-700 font-medium py-3 px-4 rounded-lg shadow-md border border-slate-200 transition-all duration-200 w-full">
              <i className="fas fa-bookmark mr-2"></i>
              Bookmarks
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
