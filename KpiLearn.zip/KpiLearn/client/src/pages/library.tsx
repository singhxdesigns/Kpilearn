import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getBookmarkedKpis, toggleBookmark } from "../lib/local-storage";
import type { Kpi } from "@shared/schema";

type FilterType = "all" | "beginner" | "intermediate" | "advanced";
type CategoryType = "all" | "Analytics" | "Marketing" | "Engagement" | "Revenue" | "Economics" | "Strategy" | "UX" | "E-commerce" | "Product" | "Technical" | "Growth" | "Retention" | "Conversion" | "Customer Satisfaction" | "Onboarding" | "Sales";

export default function Library() {
  const [difficultyFilter, setDifficultyFilter] = useState<FilterType>("all");
  const [categoryFilter, setCategoryFilter] = useState<CategoryType>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  // Fetch all KPIs from all difficulty levels
  const { data: beginnerKpis } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis", "beginner"],
  });
  
  const { data: intermediateKpis } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis", "intermediate"],
  });
  
  const { data: advancedKpis } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis", "advanced"],
  });

  // Combine all KPIs
  const allKpis = [
    ...(beginnerKpis || []),
    ...(intermediateKpis || []),
    ...(advancedKpis || [])
  ];

  const bookmarkedKpis = getBookmarkedKpis();

  // Filter KPIs based on selected filters
  const filteredKpis = allKpis.filter(kpi => {
    const matchesDifficulty = difficultyFilter === "all" || kpi.difficulty === difficultyFilter;
    const matchesCategory = categoryFilter === "all" || kpi.category === categoryFilter;
    const matchesSearch = searchQuery === "" || 
      kpi.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      kpi.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      kpi.explanation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      kpi.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    return matchesDifficulty && matchesCategory && matchesSearch;
  });

  // Get unique categories for filter dropdown
  const categories = Array.from(new Set(allKpis.map(kpi => kpi.category).filter(Boolean))).sort();

  const handleToggleBookmark = (kpiId: string) => {
    toggleBookmark(kpiId);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-success text-white";
      case "intermediate": return "bg-warning text-white";
      case "advanced": return "bg-accent text-white";
      default: return "bg-slate-500 text-white";
    }
  };

  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "fa-seedling";
      case "intermediate": return "fa-chart-bar";
      case "advanced": return "fa-rocket";
      default: return "fa-circle";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Header */}
        <div className="mb-6">
          <Link href="/">
            <button className="flex items-center text-slate-600 hover:text-slate-800 transition-colors mb-4">
              <i className="fas fa-arrow-left mr-2"></i>
              Back to Home
            </button>
          </Link>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">KPI Library</h2>
              <p className="text-slate-600">Complete collection of {allKpis.length} product & design metrics</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-500">Showing {filteredKpis.length} KPIs</p>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-6">
          {/* Search Bar */}
          <div className="relative mb-4">
            <input 
              type="text" 
              placeholder="Search KPIs, metrics, or concepts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg py-3 pl-10 pr-4 text-slate-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
            <i className="fas fa-search absolute left-3 top-4 text-slate-400"></i>
          </div>

          {/* Filter Buttons */}
          <div className="flex flex-wrap gap-3">
            {/* Difficulty Filter */}
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-slate-600">Level:</span>
              {(["all", "beginner", "intermediate", "advanced"] as FilterType[]).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setDifficultyFilter(filter)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                    difficultyFilter === filter
                      ? "bg-primary text-white"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {filter === "all" ? "All" : filter.charAt(0).toUpperCase() + filter.slice(1)}
                </button>
              ))}
            </div>

            {/* Category Filter */}
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-slate-600">Category:</span>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value as CategoryType)}
                className="px-3 py-1 rounded-lg text-xs border border-slate-200 bg-white text-slate-600 focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="all">All Categories</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* KPI Cards Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredKpis.map((kpi) => {
            const isBookmarked = bookmarkedKpis.includes(kpi.id);
            const isExpanded = expandedCard === kpi.id;

            return (
              <div 
                key={kpi.id} 
                className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow"
              >
                {/* Card Header */}
                <div className="p-4 border-b border-slate-100">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${getDifficultyColor(kpi.difficulty)}`}>
                        <i className={`fas ${getDifficultyIcon(kpi.difficulty)} mr-1`}></i>
                        {kpi.difficulty.charAt(0).toUpperCase() + kpi.difficulty.slice(1)}
                      </span>
                      {kpi.category && (
                        <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-full">
                          {kpi.category}
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => handleToggleBookmark(kpi.id)}
                      className={`transition-colors ${
                        isBookmarked ? "text-warning" : "text-slate-300 hover:text-warning"
                      }`}
                    >
                      <i className="fas fa-bookmark text-sm"></i>
                    </button>
                  </div>
                  <h3 className="font-semibold text-slate-800 text-sm mb-1">
                    {kpi.answer}
                  </h3>
                  <p className="text-xs text-slate-600 mb-2">
                    {kpi.question}
                  </p>
                </div>

                {/* Card Content */}
                <div className="p-4">
                  <p className={`text-sm text-slate-600 leading-relaxed ${
                    isExpanded ? "" : "line-clamp-3"
                  }`}>
                    {kpi.explanation}
                  </p>
                  
                  {kpi.explanation.length > 120 && (
                    <button
                      onClick={() => setExpandedCard(isExpanded ? null : kpi.id)}
                      className="text-primary text-xs font-medium mt-2 hover:text-blue-600 transition-colors"
                    >
                      {isExpanded ? "Show less" : "Read more"}
                    </button>
                  )}

                  {/* Tags */}
                  {kpi.tags && kpi.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {kpi.tags.slice(0, 3).map((tag, index) => (
                        <span 
                          key={index}
                          className="text-xs bg-slate-100 text-slate-500 px-2 py-1 rounded"
                        >
                          #{tag}
                        </span>
                      ))}
                      {kpi.tags.length > 3 && (
                        <span className="text-xs text-slate-400">
                          +{kpi.tags.length - 3} more
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredKpis.length === 0 && (
          <div className="text-center py-12">
            <i className="fas fa-search text-4xl text-slate-300 mb-4"></i>
            <h3 className="text-lg font-semibold text-slate-600 mb-2">No KPIs Found</h3>
            <p className="text-slate-500 mb-4">
              Try adjusting your search terms or filters
            </p>
            <button
              onClick={() => {
                setSearchQuery("");
                setDifficultyFilter("all");
                setCategoryFilter("all");
              }}
              className="text-primary hover:text-blue-600 font-medium"
            >
              Clear all filters
            </button>
          </div>
        )}

        {/* Quick Stats */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg p-4 text-center shadow-sm border border-slate-200">
            <p className="text-2xl font-bold text-success">
              {allKpis.filter(k => k.difficulty === "beginner").length}
            </p>
            <p className="text-sm text-slate-600">Beginner</p>
          </div>
          <div className="bg-white rounded-lg p-4 text-center shadow-sm border border-slate-200">
            <p className="text-2xl font-bold text-warning">
              {allKpis.filter(k => k.difficulty === "intermediate").length}
            </p>
            <p className="text-sm text-slate-600">Intermediate</p>
          </div>
          <div className="bg-white rounded-lg p-4 text-center shadow-sm border border-slate-200">
            <p className="text-2xl font-bold text-accent">
              {allKpis.filter(k => k.difficulty === "advanced").length}
            </p>
            <p className="text-sm text-slate-600">Advanced</p>
          </div>
          <div className="bg-white rounded-lg p-4 text-center shadow-sm border border-slate-200">
            <p className="text-2xl font-bold text-primary">
              {categories.length}
            </p>
            <p className="text-sm text-slate-600">Categories</p>
          </div>
        </div>
      </div>
    </div>
  );
}