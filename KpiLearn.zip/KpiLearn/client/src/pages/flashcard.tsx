import { useState, useEffect } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { FlipCard } from "../components/ui/flip-card";
import { ProgressBar } from "../components/ui/progress-bar";
import { getUserId, getBookmarkedKpis, toggleBookmark, getUserProgress, updateUserProgress } from "../lib/local-storage";
import type { Kpi, DifficultyLevel } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function Flashcard() {
  const { difficulty } = useParams<{ difficulty: string }>();
  const [, setLocation] = useLocation();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [userId] = useState(getUserId());
  const [cards, setCards] = useState<Kpi[]>([]);
  const queryClient = useQueryClient();

  // Determine if this is daily practice mode
  const isDailyMode = difficulty === "daily";
  const actualDifficulty = isDailyMode ? "beginner" : (difficulty as DifficultyLevel);

  const { data: allKpis, isLoading } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis", actualDifficulty],
  });

  const { data: progress } = useQuery({
    queryKey: ["/api/progress", userId],
  });

  const updateProgressMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PATCH", `/api/progress/${userId}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress", userId] });
    }
  });

  // Initialize cards based on mode
  useEffect(() => {
    if (allKpis) {
      if (isDailyMode) {
        // For daily mode, select 5 random cards
        const shuffled = [...allKpis].sort(() => 0.5 - Math.random());
        setCards(shuffled.slice(0, 5));
      } else {
        // For difficulty mode, use all cards for that difficulty
        setCards(allKpis);
      }
      setCurrentIndex(0);
      setIsFlipped(false);
    }
  }, [allKpis, isDailyMode]);

  const bookmarkedKpis = getBookmarkedKpis();
  const currentCard = cards[currentIndex];
  const isBookmarked = currentCard ? bookmarkedKpis.includes(currentCard.id) : false;

  const handleToggleBookmark = () => {
    if (currentCard) {
      toggleBookmark(currentCard.id);
    }
  };

  const handleNext = () => {
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    } else {
      // Complete the session
      handleCompleteSession();
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setIsFlipped(false);
    }
  };

  const handleCompleteSession = async () => {
    if (isDailyMode) {
      // Update daily progress
      const today = new Date();
      const newStreak = shouldIncrementStreak() ? ((progress as any)?.currentStreak || 0) + 1 : (progress as any)?.currentStreak || 0;
      
      await updateProgressMutation.mutateAsync({
        todaysProgress: 5,
        lastPracticeDate: today.toISOString(),
        currentStreak: newStreak,
        totalCardsStudied: ((progress as any)?.totalCardsStudied || 0) + 5
      });
    }
    
    setLocation("/completion");
  };

  const shouldIncrementStreak = () => {
    if (!(progress as any)?.lastPracticeDate) return true;
    
    const today = new Date().toDateString();
    const lastPracticeDate = new Date((progress as any).lastPracticeDate).toDateString();
    
    return lastPracticeDate !== today;
  };

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case "beginner": return "bg-success";
      case "intermediate": return "bg-warning";
      case "advanced": return "bg-accent";
      default: return "bg-primary";
    }
  };

  const getDifficultyLabel = () => {
    if (isDailyMode) return "Daily Practice";
    return difficulty?.charAt(0).toUpperCase() + difficulty?.slice(1);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!currentCard) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600 mb-4">No flashcards available</p>
          <Link href="/">
            <button className="bg-primary text-white px-4 py-2 rounded">Back to Home</button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-6 max-w-md">
        {/* Header with Progress */}
        <div className="flex items-center justify-between mb-6">
          <Link href="/">
            <button className="w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center text-slate-600 hover:text-slate-800 transition-colors">
              <i className="fas fa-times"></i>
            </button>
          </Link>
          
          <div className="flex-1 mx-4">
            <ProgressBar 
              current={currentIndex + 1} 
              total={cards.length} 
            />
            <p className="text-center text-sm text-slate-600 mt-1">
              Card {currentIndex + 1} of {cards.length}
            </p>
          </div>
          
          <button 
            onClick={handleToggleBookmark}
            className={`w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center transition-colors ${
              isBookmarked ? "text-warning" : "text-slate-600 hover:text-warning"
            }`}
          >
            <i className={`fas fa-bookmark`}></i>
          </button>
        </div>

        {/* Flashcard */}
        <div className="mb-8">
          <FlipCard
            question={currentCard.question}
            answer={currentCard.answer}
            explanation={currentCard.explanation}
            isFlipped={isFlipped}
            onFlip={() => setIsFlipped(!isFlipped)}
          />
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <button 
            onClick={() => setIsFlipped(!isFlipped)}
            className="w-full bg-primary hover:bg-blue-600 text-white font-semibold py-4 px-6 rounded-xl shadow-lg transition-all duration-200"
          >
            <i className="fas fa-sync-alt mr-2"></i>
            {isFlipped ? "Show Question" : "Reveal Answer"}
          </button>
          
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={handlePrevious}
              disabled={currentIndex === 0}
              className="bg-white hover:bg-slate-50 text-slate-700 font-medium py-3 px-4 rounded-lg shadow-md border border-slate-200 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <i className="fas fa-chevron-left mr-2"></i>
              Previous
            </button>
            
            <button 
              onClick={handleNext}
              className="bg-white hover:bg-slate-50 text-slate-700 font-medium py-3 px-4 rounded-lg shadow-md border border-slate-200 transition-all duration-200"
            >
              {currentIndex === cards.length - 1 ? "Complete" : "Next"}
              <i className={`fas ${currentIndex === cards.length - 1 ? "fa-check" : "fa-chevron-right"} ml-2`}></i>
            </button>
          </div>
        </div>

        {/* Difficulty Badge */}
        <div className="flex justify-center mt-6">
          <span className={`${getDifficultyColor(actualDifficulty)} text-white text-xs font-medium px-3 py-1 rounded-full`}>
            {getDifficultyLabel()}
          </span>
        </div>
      </div>
    </div>
  );
}
