import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getBookmarkedKpis, toggleBookmark } from "../lib/local-storage";
import type { Kpi } from "@shared/schema";

export default function Bookmarks() {
  const [, setLocation] = useLocation();
  const bookmarkedKpis = getBookmarkedKpis();

  // We need to fetch the actual KPI data for bookmarked items
  // Since we can't fetch by multiple IDs, we'll fetch all and filter client-side
  const { data: beginnerKpis } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis", "beginner"],
  });
  
  const { data: intermediateKpis } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis", "intermediate"],
  });
  
  const { data: advancedKpis } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis", "advanced"],
  });

  const allKpis = [
    ...(beginnerKpis || []),
    ...(intermediateKpis || []),
    ...(advancedKpis || [])
  ];

  const bookmarkedKpiData = allKpis.filter(kpi => bookmarkedKpis.includes(kpi.id));

  const handleRemoveBookmark = (kpiId: string) => {
    toggleBookmark(kpiId);
    // Force a re-render by updating local state
    window.location.reload();
  };

  const handleStudyKpi = (kpi: Kpi) => {
    // Navigate to flashcard page for this specific KPI's difficulty
    setLocation(`/flashcard/${kpi.difficulty}`);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-success text-white";
      case "intermediate": return "bg-warning text-white";
      case "advanced": return "bg-accent text-white";
      default: return "bg-slate-500 text-white";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <div className="mb-6">
          <Link href="/">
            <button className="flex items-center text-slate-600 hover:text-slate-800 transition-colors mb-4">
              <i className="fas fa-arrow-left mr-2"></i>
              Back
            </button>
          </Link>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Your Bookmarks</h2>
          <p className="text-slate-600">KPIs you've saved for later review</p>
        </div>

        {/* Bookmarked Items */}
        <div className="space-y-4">
          {bookmarkedKpiData.length === 0 ? (
            <div className="text-center py-12">
              <i className="fas fa-bookmark text-6xl text-slate-300 mb-4"></i>
              <h3 className="text-lg font-semibold text-slate-600 mb-2">No Bookmarks Yet</h3>
              <p className="text-slate-500 mb-6">Start bookmarking KPIs you want to review later</p>
              <Link href="/search">
                <button className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors">
                  Search KPIs
                </button>
              </Link>
            </div>
          ) : (
            bookmarkedKpiData.map((kpi) => (
              <div key={kpi.id} className="bg-white rounded-xl shadow-lg border border-slate-100 p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold text-slate-800 flex-1 pr-2">
                    {kpi.answer}
                  </h3>
                  <button 
                    onClick={() => handleRemoveBookmark(kpi.id)}
                    className="text-warning hover:text-orange-600 transition-colors"
                  >
                    <i className="fas fa-bookmark"></i>
                  </button>
                </div>
                <p className="text-slate-600 text-sm mb-3">
                  {kpi.explanation.length > 120 
                    ? `${kpi.explanation.substring(0, 120)}...` 
                    : kpi.explanation
                  }
                </p>
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-medium px-2 py-1 rounded ${getDifficultyColor(kpi.difficulty)}`}>
                    {kpi.difficulty.charAt(0).toUpperCase() + kpi.difficulty.slice(1)}
                  </span>
                  <button 
                    onClick={() => handleStudyKpi(kpi)}
                    className="text-primary hover:text-blue-600 font-medium text-sm transition-colors"
                  >
                    Study Now <i className="fas fa-arrow-right ml-1"></i>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
