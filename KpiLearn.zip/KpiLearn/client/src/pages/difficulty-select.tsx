import { Link } from "wouter";

export default function DifficultySelect() {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <div className="mb-8">
          <Link href="/">
            <button className="flex items-center text-slate-600 hover:text-slate-800 transition-colors mb-4">
              <i className="fas fa-arrow-left mr-2"></i>
              Back
            </button>
          </Link>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Choose Your Level</h2>
          <p className="text-slate-600">Select the difficulty that matches your experience</p>
        </div>

        <div className="space-y-4">
          <Link href="/flashcard/beginner">
            <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden hover:shadow-xl transition-shadow cursor-pointer">
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <div className="w-10 h-10 bg-success rounded-full flex items-center justify-center mr-3">
                    <i className="fas fa-seedling text-white"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800">Beginner</h3>
                </div>
                <p className="text-slate-600 mb-3">Basic definitions and fundamental concepts</p>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-slate-100 text-slate-700 text-xs font-medium px-2 py-1 rounded">DAU</span>
                  <span className="bg-slate-100 text-slate-700 text-xs font-medium px-2 py-1 rounded">MAU</span>
                  <span className="bg-slate-100 text-slate-700 text-xs font-medium px-2 py-1 rounded">NPS</span>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/flashcard/intermediate">
            <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden hover:shadow-xl transition-shadow cursor-pointer">
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <div className="w-10 h-10 bg-warning rounded-full flex items-center justify-center mr-3">
                    <i className="fas fa-chart-bar text-white"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800">Intermediate</h3>
                </div>
                <p className="text-slate-600 mb-3">Applied metrics and analysis techniques</p>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-slate-100 text-slate-700 text-xs font-medium px-2 py-1 rounded">Cohort Retention</span>
                  <span className="bg-slate-100 text-slate-700 text-xs font-medium px-2 py-1 rounded">CAC vs LTV</span>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/flashcard/advanced">
            <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden hover:shadow-xl transition-shadow cursor-pointer">
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center mr-3">
                    <i className="fas fa-rocket text-white"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800">Advanced</h3>
                </div>
                <p className="text-slate-600 mb-3">Strategic metrics and complex analysis</p>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-slate-100 text-slate-700 text-xs font-medium px-2 py-1 rounded">North Star Metric</span>
                  <span className="bg-slate-100 text-slate-700 text-xs font-medium px-2 py-1 rounded">ARPU</span>
                </div>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
