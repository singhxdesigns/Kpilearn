import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getBookmarkedKpis, toggleBookmark } from "../lib/local-storage";
import type { Kpi } from "@shared/schema";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: searchResults, isLoading } = useQuery<Kpi[]>({
    queryKey: ["/api/kpis/search", searchQuery],
    enabled: searchQuery.length >= 2,
  });

  const bookmarkedKpis = getBookmarkedKpis();

  const handleToggleBookmark = (kpiId: string) => {
    toggleBookmark(kpiId);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-success text-white";
      case "intermediate": return "bg-warning text-white";
      case "advanced": return "bg-accent text-white";
      default: return "bg-slate-500 text-white";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <div className="mb-6">
          <Link href="/">
            <button className="flex items-center text-slate-600 hover:text-slate-800 transition-colors mb-4">
              <i className="fas fa-arrow-left mr-2"></i>
              Back
            </button>
          </Link>
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Search KPIs</h2>
          
          {/* Search Input */}
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search for a KPI..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-xl py-4 pl-12 pr-4 text-slate-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent shadow-sm"
            />
            <i className="fas fa-search absolute left-4 top-5 text-slate-400"></i>
          </div>
        </div>

        {/* Search Results */}
        <div className="space-y-3">
          {isLoading && searchQuery.length >= 2 && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-slate-600 mt-2">Searching...</p>
            </div>
          )}
          
          {searchQuery.length < 2 && (
            <div className="text-center py-8 text-slate-500">
              <i className="fas fa-search text-4xl mb-4"></i>
              <p>Type at least 2 characters to search</p>
            </div>
          )}

          {searchResults && searchResults.length === 0 && searchQuery.length >= 2 && (
            <div className="text-center py-8 text-slate-500">
              <i className="fas fa-search text-4xl mb-4"></i>
              <p>No KPIs found matching "{searchQuery}"</p>
            </div>
          )}

          {searchResults && searchResults.map((kpi) => {
            const isBookmarked = bookmarkedKpis.includes(kpi.id);
            
            return (
              <div 
                key={kpi.id} 
                className="bg-white rounded-lg shadow-md border border-slate-100 p-4 hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-slate-800 mb-1">
                      {kpi.answer} ({kpi.question.replace(/^What (does|is|are) |^How /, "").replace(/\?$/, "")})
                    </h3>
                    <p className="text-sm text-slate-600 mb-2">
                      {kpi.explanation.length > 100 
                        ? `${kpi.explanation.substring(0, 100)}...` 
                        : kpi.explanation
                      }
                    </p>
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-medium px-2 py-1 rounded ${getDifficultyColor(kpi.difficulty)}`}>
                        {kpi.difficulty.charAt(0).toUpperCase() + kpi.difficulty.slice(1)}
                      </span>
                      <button
                        onClick={() => handleToggleBookmark(kpi.id)}
                        className={`transition-colors ${
                          isBookmarked ? "text-warning" : "text-slate-300 hover:text-warning"
                        }`}
                      >
                        <i className="fas fa-bookmark"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
